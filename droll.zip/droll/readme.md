## Project Description

* [live example](https://learning-zone.github.io/website-templates/droll/)

![alt text](https://github.com/learning-zone/Website-Templates/blob/master/assets/droll.png "droll")
